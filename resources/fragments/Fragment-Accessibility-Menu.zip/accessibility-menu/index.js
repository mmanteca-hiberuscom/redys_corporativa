(function () {
    var menu = document.querySelector("#accessibilityMenu");
    var button = document.querySelector(".accessibility-button");
    var widget = document.querySelector(".accessibility-widget");
    var fontSize = 100;
    var lineHeight = 150;

    if (!button || !menu) {
        console.error("Accessibility button or menu not found!");
        return;
    }

    // Cargar configuraciones desde sessionStorage
    var storedFontSize = sessionStorage.getItem("fontSize");
    var storedLineHeight = sessionStorage.getItem("lineHeight");

    if (storedFontSize) {
        fontSize = parseInt(storedFontSize);
        document.documentElement.style.fontSize = fontSize + "%";
    }

    if (storedLineHeight) {
        lineHeight = parseInt(storedLineHeight);
        document.documentElement.style.lineHeight = lineHeight + "%";
    }

    if (sessionStorage.getItem("highContrast") === "true") document.body.classList.add("high-contrast");
    if (sessionStorage.getItem("negativeContrast") === "true") document.body.classList.add("negative-contrast");
    if (sessionStorage.getItem("lightBackground") === "true") document.body.classList.add("light-background");
    if (sessionStorage.getItem("grayscale") === "true") document.body.classList.add("grayscale");
    if (sessionStorage.getItem("readableFont") === "true") document.body.classList.add("readable-font");
    if (sessionStorage.getItem("underlineLinks") === "true") document.body.classList.add("underline-links");
    if (sessionStorage.getItem("noAnimations") === "true") document.body.classList.add("no-animations");

    if (sessionStorage.getItem("grayscale") === "true") {
        menu.style.position = "fixed";
    } else {
        menu.style.position = "";
    }

    // Abrir/cerrar menú
    button.addEventListener("click", function (event) {
        event.preventDefault();
        widget.classList.toggle("open");
    });

    // Cierre al hacer clic fuera
    document.addEventListener("click", function (event) {
        const isClickInsideMenu = menu.contains(event.target);
        const isClickOnButton = button.contains(event.target);
        if (!isClickInsideMenu && !isClickOnButton && widget.classList.contains("open")) {
            widget.classList.remove("open");
        }
    });

    var actions = {
        increaseTextSize: function (event) {
            event.preventDefault();
            if (fontSize < 130) {
                fontSize += 10;
                lineHeight += 10;
                document.documentElement.style.fontSize = fontSize + "%";
                document.documentElement.style.lineHeight = lineHeight + "%";
                saveSettings();
            }
        },
        decreaseTextSize: function (event) {
            event.preventDefault();
            if (fontSize > 70) {
                fontSize -= 10;
                lineHeight = Math.max(120, lineHeight - 10);
                document.documentElement.style.fontSize = fontSize + "%";
                document.documentElement.style.lineHeight = lineHeight + "%";
                saveSettings();
            }
        },
        toggleGrayscale: function (event) {
            event.preventDefault();
            document.body.classList.toggle("grayscale");
            if (document.body.classList.contains("grayscale")) {
                sessionStorage.setItem("grayscale", "true");
                menu.style.position = "fixed";
            } else {
                sessionStorage.setItem("grayscale", "false");
                menu.style.position = "";
            }
        },
        toggleHighContrast: function (event) {
            event.preventDefault();
            document.body.classList.remove("negative-contrast", "light-background");
            document.body.classList.toggle("high-contrast");
            saveSettings();
        },
        toggleNegativeContrast: function (event) {
            event.preventDefault();
            document.body.classList.remove("high-contrast", "light-background");
            document.body.classList.toggle("negative-contrast");
            saveSettings();
        },
        toggleLightBackground: function (event) {
            event.preventDefault();
            document.body.classList.remove("high-contrast", "negative-contrast");
            document.body.classList.toggle("light-background");
            saveSettings();
        },
        toggleUnderlineLinks: function (event) {
            event.preventDefault();
            document.body.classList.toggle("underline-links");
					  saveSettings();
        },
        toggleReadableFont: function (event) {
            event.preventDefault();
            document.body.classList.toggle("readable-font");
            saveSettings();
        },
        toggleAnimations: function (event) {
            event.preventDefault();
            document.body.classList.toggle("no-animations");
            document.body.classList.contains("no-animations") ? stopSliders() : restartSliders();
        },
        resetAccessibility: function (event) {
            event.preventDefault();
            fontSize = 100;
            lineHeight = 150;
            document.body.removeAttribute("style");
            document.body.classList.remove(
                "high-contrast", "negative-contrast", "light-background",
                "grayscale", "readable-font", "underline-links", "no-animations"
            );
            document.documentElement.style.fontSize = "";
            if (menu) menu.style.position = "";
            sessionStorage.clear();
            restartSliders();
            document.querySelectorAll(".active-setting").forEach((el) => {
                el.classList.remove("active-setting");
            });
        }
    };

    function saveSettings() {
        sessionStorage.setItem("fontSize", fontSize);
        sessionStorage.setItem("lineHeight", lineHeight);
        sessionStorage.setItem("highContrast", document.body.classList.contains("high-contrast"));
        sessionStorage.setItem("negativeContrast", document.body.classList.contains("negative-contrast"));
        sessionStorage.setItem("lightBackground", document.body.classList.contains("light-background"));
        sessionStorage.setItem("grayscale", document.body.classList.contains("grayscale"));
        sessionStorage.setItem("readableFont", document.body.classList.contains("readable-font"));
        sessionStorage.setItem("underlineLinks", document.body.classList.contains("underline-links"));
        sessionStorage.setItem("noAnimations", document.body.classList.contains("no-animations"));
    }

    function stopSliders() {
        $("video[aria-label='colum2']").each(function () { this.pause(); });
        if (window.jQuery && jQuery.fn.slick && jQuery('.slider, .carousel').hasClass('slick-initialized')) {
            jQuery('.slider, .carousel').slick('slickPause');
        }
        if (window.Swiper) {
            document.querySelectorAll('.swiper-container').forEach(function (swiperEl) {
                if (swiperEl.swiper) swiperEl.swiper.autoplay.stop();
            });
        }
        document.querySelectorAll('.carousel').forEach(function (carousel) {
            if (typeof bootstrap !== "undefined" && bootstrap.Carousel) {
                try {
                    var instance = bootstrap.Carousel.getInstance(carousel) || new bootstrap.Carousel(carousel);
                    instance.pause();
                } catch (error) {}
            }
        });
        document.querySelectorAll('.component-slider').forEach(function (slider) {
            var fragmentElement = slider.closest('[id^="fragment-"]');
            if (fragmentElement) {
                var toggleButton = fragmentElement.querySelector('.carousel-toggle-button');
                if (toggleButton && toggleButton.classList.contains('playing')) {
                    toggleButton.click();
                }
            }
        });
    }

    function restartSliders() {
        $("video[aria-label='colum2']").each(function () { this.play(); });
        if (window.jQuery && jQuery.fn.slick && jQuery('.slider, .carousel').hasClass('slick-initialized')) {
            jQuery('.slider, .carousel').slick('slickPlay');
        }
        if (window.Swiper) {
            document.querySelectorAll('.swiper-container').forEach(function (swiperEl) {
                if (swiperEl.swiper) swiperEl.swiper.autoplay.start();
            });
        }
        document.querySelectorAll('.carousel').forEach(function (carousel) {
            if (typeof bootstrap !== "undefined" && bootstrap.Carousel) {
                try {
                    var instance = bootstrap.Carousel.getInstance(carousel) || new bootstrap.Carousel(carousel);
                    instance.cycle();
                } catch (error) {}
            }
        });
        document.querySelectorAll('.component-slider').forEach(function (slider) {
            var fragmentElement = slider.closest('[id^="fragment-"]');
            if (fragmentElement) {
                var toggleButton = fragmentElement.querySelector('.carousel-toggle-button');
                if (toggleButton && toggleButton.classList.contains('stopped')) {
                    toggleButton.click();
                }
            }
        });
    }

    // Aplicar clase activa al cargar solo si está en sessionStorage
    document.querySelectorAll("[data-action]").forEach((btn) => {
        const action = btn.getAttribute("data-action");
        if (
            action &&
            sessionStorage.getItem(action) === "true" &&
            action !== "resetAccessibility" &&
            action !== "increaseTextSize" &&
            action !== "decreaseTextSize"
        ) {
            btn.classList.add("active-setting");
        }
    });

    // Añadir eventos con control de clase activa
    widget.querySelectorAll("[data-action]").forEach(function (btn) {
        var actionName = btn.getAttribute("data-action");
        if (!actions[actionName]) return;

        btn.addEventListener("click", function (event) {
            actions[actionName](event);

            if (actionName === "resetAccessibility") return;

            const exclusive = ["toggleHighContrast", "toggleNegativeContrast", "toggleLightBackground"];
            const isExclusive = exclusive.includes(actionName);
            const isSizeControl = ["increaseTextSize", "decreaseTextSize"].includes(actionName);

            if (isSizeControl) {
	// Desactivar el otro botón de tamaño
	const otherAction = actionName === "increaseTextSize" ? "decreaseTextSize" : "increaseTextSize";
	const otherBtn = widget.querySelector(`[data-action="${otherAction}"]`);
	if (otherBtn && otherBtn.classList.contains("active-setting")) {
		otherBtn.classList.remove("active-setting");
	}

	// Activar el actual si aún no lo está
	if (!btn.classList.contains("active-setting")) {
		btn.classList.add("active-setting");
	}
	return;
}

            const isActive = sessionStorage.getItem(actionName) === "true";
            const newValue = !isActive;
            sessionStorage.setItem(actionName, newValue ? "true" : "false");

            if (isExclusive) {
                exclusive.forEach(function (exclusiveAction) {
                    const otherBtn = widget.querySelector(`[data-action="${exclusiveAction}"]`);
                    if (otherBtn && exclusiveAction !== actionName) {
                        otherBtn.classList.remove("active-setting");
                        sessionStorage.setItem(exclusiveAction, "false");
                    }
                });
            }

            if (newValue) {
                btn.classList.add("active-setting");
            } else {
                btn.classList.remove("active-setting");
            }
        });
    });
})();