(function () {
    const buttonUp = fragmentElement.querySelector('.button-up__link');
    if (buttonUp) {
        buttonUp.addEventListener('click', (event) => {
    setTimeout(() => event.currentTarget.blur(), 300);
});
			
Liferay.on('allPortletsReady', function () {
		$('a[href="/cookie-modal"]').on('click', function (e) {
			e.preventDefault();
			$('#cookieModal').modal('show');
		});
	});
			
			document.addEventListener('DOMContentLoaded', function () {
	const staticLi = document.querySelector('.static-header');
	const menuUl = document.querySelector('.portlet-navigation ul.navbar-nav');

	if (staticLi && menuUl) {
		staticLi.style.display = 'flex';
		menuUl.prepend(staticLi);
	}
});
    }
})();