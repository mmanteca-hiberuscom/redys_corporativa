let configModalButton = fragmentElement.querySelector('.configura-modal__btn');
let acceptButton = fragmentElement.querySelector('.cookie-banner-accept');
let rejectButton = fragmentElement.querySelector('.cookie-banner-reject');

let editMode = layoutMode === 'edit';


// Función principal
function main() {
	
	if (!editMode) {
		
	    acceptButton.addEventListener('click', acceptAllCookies);  
		rejectButton.addEventListener('click', acceptNecessaryOnly);  
		configModalButton.addEventListener('click', closeModal);

		let hasAcceptedCookies = getCookie('CONSENT_TYPE_NECESSARY') === 'true';

		if (!hasAcceptedCookies) {
		 
			//abrir el modal
			$('#homeCookieModal').modal('show');
			/*$('#homeCookieModal').on('hidden.bs.modal', function () {
        $('#cookiePolicyModal').modal('show');
    });*/ }
		
	}
}

main();

// Acepta solo cookies necesarias
function acceptNecessaryOnly() {
	setCookie('CONSENT_TYPE_NECESSARY', 'true', 365);
	closeModal();
}

// Acepta todas las cookies (necesarias + de terceros)
function acceptAllCookies() {
	setCookie('CONSENT_TYPE_NECESSARY', 'true', 365);
	setCookie('CONSENT_TYPE_FUNCTIONAL', 'true', 365);  
	closeModal();
}

// Función para obtener el valor de una cookie
function getCookie(name) {
    let nameEQ = name + "=";
    let ca = document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) === ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

function closeModal() {
	    $('#homeCookieModal').modal('hide');
}
function setCookie(name, value, days) {
    let expires = "";
    if (days) {
        let date = new Date();
        date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + value + "; path=/" + expires;
}