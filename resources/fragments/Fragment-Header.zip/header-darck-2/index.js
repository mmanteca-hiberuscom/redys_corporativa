Liferay.on('allPortletsReady', function () {
	const namespace = `${fragmentEntryLinkNamespace}`;

	const $hamburgerBtn = $("#" + namespace + "-hamburgerBtn");
	const $closeBtn = $("#" + namespace + "-closeBtn");
	const $modalMenu = $("#" + namespace + "-r-modal");
	const $mainMenu = $("#" + namespace + "-main-menu");
	const $modalWrapper = $("#" + namespace + "-r-modal__wrapper");
	const $containerMenu = $("#" + namespace + "-container-menu");
	const $supramenuLinks = $("#" + namespace + "-supramenu-links-mobile");
	const $header = $(".header");

	$header.addClass("init");
	setTimeout(() => {
		$header.removeClass("init");
	}, 100);

	let headerFixed = false;
	let lockHeader = false;

	function bloquearHeaderScroll(ms = 300) {
		lockHeader = true;
		setTimeout(() => {
			lockHeader = false;
		}, ms);
	}
	
	function activarEnlacesConAncla() {
	$(document).on("click", "#" + namespace + "-main-menu a[href*='#']", function (e) {
		const $link = $(this);
		const href = $link.attr("href");
		if (!href) return;

		const linkUrl = new URL(href, window.location.origin);
		const linkPath = linkUrl.pathname;
		const linkHash = linkUrl.hash;
		const currentPath = window.location.pathname;

		if (linkPath !== currentPath) return;

		$("#" + namespace + "-main-menu a[href*='#']").each(function () {
			const $li = $(this).closest("li");
			$li.removeClass("active selected");
			const $parentLi = $li.closest("ul.child-menu").closest("li");
			if ($parentLi.length) {
				$parentLi.removeClass("active-parent");
			}
		});

		const $li = $link.closest("li").addClass("active selected");
		const $parentLi = $li.closest("ul.child-menu").closest("li");
		if ($parentLi.length) {
			$parentLi.addClass("active-parent");
		}
	});
}

activarEnlacesConAncla();

	function markTopLevelMenuActive() {
		const $activeItems = $("#" + namespace + "-main-menu .selected, #" + namespace + "-main-menu .active");

		$activeItems.each(function () {
			const $li = $(this).closest("li");
			let hasChildren = false;

			if ($li.find("ul.child-menu").length > 0) {
				$li.addClass("active-parent");
				hasChildren = true;
			}

			const $topLevelLi = $li.closest("ul").closest("li");
			if ($topLevelLi.length > 0 && $topLevelLi.find("ul.child-menu").length > 0) {
				$topLevelLi.addClass("active-parent");
				hasChildren = true;
			}
		});
	}

	if (window.innerWidth >= 1199.98) {
		markTopLevelMenuActive();
	}

	function moveMenu() {
		if (window.innerWidth <= 1199.98) {
			if (!$modalWrapper.has($mainMenu).length) {
				$modalWrapper.append($mainMenu);
			}
			if (!$modalWrapper.has($supramenuLinks).length) {
				$modalWrapper.append($supramenuLinks);
			}
			$hamburgerBtn.show();
		} else {
			closeMenu();
			$hamburgerBtn.hide();
			$closeBtn.hide();
			$("body").removeClass("no-scroll");
			if (!$containerMenu.has($mainMenu).length) {
				$containerMenu.append($mainMenu);
			}
			$(".supramenu #" + namespace + "-supramenu-links-mobile").remove();
			$(".supramenu").prepend($supramenuLinks);
		}
	}

	function openMenu() {
		$modalMenu.addClass("open").attr("aria-hidden", "false");
		$hamburgerBtn.hide();
		$closeBtn.show();
		$("body").addClass("no-scroll");
	}

	function closeMenu() {
		$modalMenu.removeClass("open").attr("aria-hidden", "true");
		$hamburgerBtn.show();
		$closeBtn.hide();
		$("body").removeClass("no-scroll");
	}

	$hamburgerBtn.on("click", function () {
	//	console.log("Abriendo menu");
		openMenu();
	});
	$closeBtn.on("click", function () {
		closeMenu();
	});

	$(document).on("mouseenter", "#" + namespace + "-main-menu li", function () {
		if (window.innerWidth > 1199.98) {
			$(this).removeClass("hover open");
		}
	});

	$(document)
		.off("click", "#" + namespace + "-main-menu a")
		.on("click", "#" + namespace + "-main-menu a", function (event) {
			let $link = $(this);
			let $parentLi = $link.closest("li");
			let href = $link.attr("href");

			if (!href || href === "#") {
				event.preventDefault();
				$parentLi.toggleClass("open hover");
			} else if (window.innerWidth <= 1199.98) {
				closeMenu();
			}
		});

	$(document).on("click", function (event) {
		if (
			$modalMenu.hasClass("open") &&
			!$(event.target).closest("#" + namespace + "-r-modal__wrapper").length &&
			!$(event.target).closest("#" + namespace + "-hamburgerBtn").length
		) {
			closeMenu();
		}
	});

	moveMenu();

	$(window).on("resize", function () {
		moveMenu();
	});

	function replaceLiferayDropdownIcons() {
		$(".lexicon-icon-angle-down").each(function () {
			const newIcon = `
<svg class="custom-arrow" width="12" height="6" viewBox="0 0 12 6" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M1 1L6 5L11 1" stroke="#FE5B02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>`;
			$(this).replaceWith(newIcon);
		});
	}
});