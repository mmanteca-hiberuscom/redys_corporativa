let cookieBanner = fragmentElement.querySelector('.cookie-banner');
let closeButton = fragmentElement.querySelector('.cookie-banner-close');
let saveButton = fragmentElement.querySelector('.cookie-banner-save');
let thirdPartyCheckbox = document.querySelector('#cookies-third-party');
let cookieModal = document.querySelector('#cookiePolicyModal');
let cancelButton = document.querySelector('.cookie-modal__btn-white');
let technicalCheckbox = fragmentElement.querySelector('#cookies-technical');
let editMode = typeof layoutMode !== 'undefined' && layoutMode === 'edit';
let errorMessage = document.querySelector('#error-message');

function hideBanner() {
	cookieBanner.style.display = 'none';
}

function main() {
	if (!editMode) {
		loadCookiePreferences();

		// Interceptar clics en enlaces con data-toggle="modal"
		$('body').on('click', 'a[data-toggle="modal"]', function (e) {
			e.preventDefault();
			const modalSelector = $(this).attr('data-target');
			const $modal = $(modalSelector);

			if ($modal.length && typeof $modal.modal === 'function') {
				$modal.modal('show');
			}
		});

		// Interceptar clics en enlaces que abren /configurar-cookies
		document.body.addEventListener('click', function (e) {
			const target = e.target.closest('a[href="/configurar-cookies"]');
			if (target) {
				e.preventDefault();
				const $modal = $('#cookiePolicyModal');
				if ($modal.length && typeof $modal.modal === 'function') {
					$modal.modal('show');
				}
			}
		});

		// Al abrir el modal, cargar estado de cookies
		$('#cookiePolicyModal').on('show.bs.modal', loadCookiePreferences);

		// Eventos en botones
		saveButton.addEventListener('click', savePreferences);
		cancelButton.addEventListener('click', cancelPreferences);
	}
}

main();

function setCookie(name, value, days) {
	let expires = "";
	if (days) {
		let date = new Date();
		date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
		expires = "; expires=" + date.toUTCString();
	}
	document.cookie = name + "=" + value + "; path=/" + expires;
}

function getCookie(name) {
	let nameEQ = name + "=";
	let ca = document.cookie.split(';');
	for (let i = 0; i < ca.length; i++) {
		let c = ca[i];
		while (c.charAt(0) === ' ') c = c.substring(1);
		if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length);
	}
	return null;
}

function loadCookiePreferences() {
	//console.log("...loadCookiePreferences...");
	errorMessage.style.display = 'none';

	// Forzamos siempre las cookies técnicas como activadas y deshabilitadas
	technicalCheckbox.checked = true;
	technicalCheckbox.disabled = true;

	let thirdPartyAccepted = getCookie('CONSENT_TYPE_FUNCTIONAL') === 'true';
	thirdPartyCheckbox.checked = thirdPartyAccepted;

	//console.log("Mostrando opciones de cookies");
}

function savePreferences() {
//	console.log("savePreferences...");

	// Guardar siempre que las cookies técnicas están aceptadas
	setCookie('CONSENT_TYPE_NECESSARY', 'true', 365);
	setCookie(
		'CONSENT_TYPE_FUNCTIONAL',
		thirdPartyCheckbox.checked ? 'true' : 'false',
		365
	);
	$('#cookiePolicyModal').modal('hide');
}

function cancelPreferences() {
//	console.log("cancelPreferences...");
	errorMessage.style.display = 'none';
	$('#cookiePolicyModal').modal('hide');
}